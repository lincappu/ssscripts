# ssscripts
ssscripts  this script is set up to ss proxy server automaticly.
