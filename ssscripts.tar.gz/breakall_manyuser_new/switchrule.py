def getKeys():
	return ['port', 'u', 'd', 'transfer_enable', 'passwd', 'enable' ]

def isTurnOn(row):
	return True

