﻿#Config
MYSQL_HOST = 'localhost'
MYSQL_PORT = 3306
MYSQL_USER = 'wolflink'
MYSQL_PASS = 'wolflink2015'
MYSQL_DB = 'shadowsocks'

MANAGE_PASS = 'wolflink2015'
#if you want manage in other server you should set this value to global ip
MANAGE_BIND_IP = '127.0.0.1'
#make sure this port is idle
MANAGE_PORT = 23333
